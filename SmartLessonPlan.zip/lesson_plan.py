# Save this as lesson_plan.py

from openai import OpenAI
import os
import json
from dotenv import load_dotenv
import re
from interdisciplinary_lesson_plan import generate_interdisciplinary_lesson_plan
from age_guidelines import GRADE_AGE_MAPPING, get_age_appropriate_guidelines

# Load environment variables
load_dotenv()

# Debug: Print environment details
print(f"Current working directory: {os.getcwd()}")
print(f"Environment file path: {os.path.join(os.getcwd(), '.env')}")

# Initialize the OpenAI client
api_key = os.getenv('OPENAI_API_KEY')
print(f"API Key loaded: {'Yes' if api_key else 'No'}")
if api_key:
    print(f"API Key starts with: {api_key[:7]}...")

if not api_key:
    raise ValueError("OpenAI API key not found in environment variables")

client = OpenAI(
    api_key=api_key,
    base_url="https://api.openai.com/v1"
)

def calculate_time_distribution(lesson_duration, grade_level):
    """
    Calculate time distribution for different stages based on grade level.
    Returns a dictionary with time allocations for each stage.
    """
    try:
        lesson_duration = int(lesson_duration)
    except (ValueError, TypeError):
        raise ValueError("Lesson duration must be a number")
    
    # Base time distribution
    time_distribution = {
        "introduction": 0.15 * lesson_duration,     # 15% of total time
        "competence_development": 0.40 * lesson_duration,  # 40% of total time
        "design": 0.25 * lesson_duration,           # 25% of total time
        "realisation": 0.20 * lesson_duration       # 20% of total time
    }
    
    # Adjust for certain grade levels
    if grade_level.lower() in ["form1", "form2", "form3"]:
        # More time for introduction and competence development for younger grades
        time_distribution["introduction"] *= 1.2
        time_distribution["competence_development"] *= 1.1
        time_distribution["design"] *= 0.9
        time_distribution["realisation"] *= 0.8
    elif grade_level.lower() in ["form4", "form5", "form6"]:
        # Balanced distribution for middle grades
        pass
    else:
        # More time for design and realisation for older grades
        time_distribution["introduction"] *= 0.8
        time_distribution["competence_development"] *= 0.9
        time_distribution["design"] *= 1.1
        time_distribution["realisation"] *= 1.2
    
    # Round to nearest minute
    for stage in time_distribution:
        time_distribution[stage] = round(time_distribution[stage])
    
    return time_distribution

def generate_lesson_plan(main_learningactivity, grade_level, lesson_duration, time_distribution, lesson_type="regular"):
    """
    Generate a lesson plan (regular or project-based) based on the IDDR model and 5E approach.
    
    If lesson_type is interdisciplinary, this function delegates to generate_interdisciplinary_lesson_plan.
    Otherwise, it generates a single-discipline (regular or project) lesson plan.
    """
    try:
        # Get age-appropriate guidelines
        age_guidelines = get_age_appropriate_guidelines(grade_level)
        
        # If interdisciplinary, forward to specialized function
        if lesson_type and lesson_type.lower() == 'interdisciplinary':
            return generate_interdisciplinary_lesson_plan(main_learningactivity, grade_level, lesson_duration, time_distribution)

        # Create prompt for the OpenAI API
        prompt = f"""Create a detailed lesson plan for the following specifications:

        CRITICAL LANGUAGE REQUIREMENT:
        - ALL content (Specific Learning Activities and Lesson Plan Matrix) MUST be in the SAME LANGUAGE as the Main Learning Activity
        - DO NOT translate or change the language of any content
        - Maintain the exact language used in the Main Learning Activity throughout

        Main Learning Activity: {main_learningactivity}
        Grade Level: {grade_level} ({GRADE_AGE_MAPPING[grade_level.lower().replace(" ", "_")]["description"]})
        Lesson Duration: {lesson_duration} minutes
        Lesson Type: {lesson_type}

        Time Distribution:
        - Introduction: {time_distribution['introduction']} minutes
        - Competence Development: {time_distribution['competence_development']} minutes
        - Design: {time_distribution['design']} minutes
        - Realisation: {time_distribution['realisation']} minutes

        CRITICAL INSTRUCTIONS FOR LESSON TYPE: {lesson_type.upper()}

        {f'''
        REGULAR LESSON REQUIREMENTS:
        1. Adherence to Existing Conditions:
           - Strictly follow all existing lesson plan conditions
           - Maintain the provided learning activity exactly as specified
           - Ensure grade-level appropriateness
           - Follow established lesson plan structure
           - Adhere to curriculum standards
           - MAINTAIN THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
           - Design activities that align with the grade level's core competencies

        2. Single-Discipline Focus with ICT Integration:
           - Maintain content strictly within a single discipline
           - MUST include ICT integration in at least one activity or example
           - ICT integration should be meaningful and enhance learning
           - Examples of ICT integration:
             • Using educational software or apps
             • Creating digital presentations or models
             • Using online resources or simulations
             • Incorporating digital tools for data collection/analysis
             • Using interactive whiteboards or tablets
           - Focus on depth of understanding within the specific subject
           - Develop subject-specific skills and knowledge
           - USE THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
           - Ensure ICT integration matches the grade level's technology capabilities

        3. Real-life Examples and Activities:
           - Integrate relevant real-life examples specific to the discipline
           - Ensure examples are age-appropriate and contextually relevant
           - Include practical activities that demonstrate real-world applications
           - Use examples students can easily relate to
           - Include at least one ICT-based real-world application
           - MAINTAIN THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
           - Design activities that develop the grade level's core competencies

        4. Validation and Adjustment:
           - Validate that all content strictly matches teacher-provided activity, specified grade level, single-discipline focus
           - Ensure ICT integration is appropriate for the grade level
           - Immediately adjust if the lesson deviates
           - VERIFY ALL CONTENT IS IN THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
           - Ensure activities align with the grade level's core competencies

        5. Stage-Specific Requirements:
           - INTRODUCTION:
             • Engage with discipline-specific content
             • Use real-world examples
             • Set clear learning objectives
             • Include ICT-based engagement activity
             • USE THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
             • Design activities that match the grade level's attention span and cognitive development
           - COMPETENCE DEVELOPMENT:
             • Develop subject-specific knowledge with guided practice
             • Incorporate ICT tools for practice and exploration
             • MAINTAIN THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
             • Ensure activities develop the grade level's core competencies
           - DESIGN:
             • Deepen understanding of the subject
             • Include practice exercises with feedback
             • Use ICT for enhanced learning experiences
             • USE THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
             • Design activities that challenge students appropriately for their grade level
           - REALISATION:
             • Final tasks that demonstrate subject mastery
             • Evaluate subject-specific understanding
             • Include ICT-based assessment or demonstration
             • MAINTAIN THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
             • Ensure assessment methods align with the grade level's capabilities

        6. Assessment Criteria Format:
           - Assessment criteria MUST be the learning activities from the lesson plan matrix written in simple present passive voice
           - Example: If learning activity is "Use handtools to balance a tire", then assessment criteria should be "A tire is balanced by using handtools"
           - Example: If learning activity is "Identify parts of a plant", then assessment criteria should be "Parts of a plant are identified"
           - Example: If learning activity is "Solve quadratic equations", then assessment criteria should be "Quadratic equations are solved"
           - Example: If learning activity is "Create visual aids using geometric concepts to enhance a given story", then assessment criteria can be either:
             • "Visual aids are created using geometric concepts to enhance a given story" OR
             • "Geometric concepts are used to create visual aids to enhance a given story"
           - All assessment criteria must be in passive voice, present tense
           - No qualifiers like 'correctly' or 'properly' should be used
           - Include ICT-related assessment criteria where applicable
           - MAINTAIN THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
           - Ensure assessment criteria align with the grade level's core competencies

        7. Return the plan in JSON format with:
           • \"Main_Learning_Activity\"
           • \"Specific_Learning_Activities\" with sub-activities
           • \"Lesson_Plan\" with IDDR + 5E stages
           • \"Remarks\" as a single list
           • ALL CONTENT MUST BE IN THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
        ''' if lesson_type and lesson_type.lower() == 'regular' else ''}

        {f'''
        PROJECT-BASED LESSON REQUIREMENTS:
        1. Design an extended, hands-on project that spans multiple sessions
        2. Include clear project goals, deliverables, and success criteria
        3. Incorporate student choice and autonomy
        4. Focus on problem-solving and critical thinking
        5. Assessment Criteria Format:
           - Assessment criteria MUST be the learning activities from the lesson plan matrix written in simple present passive voice
           - Example: If learning activity is "Design a sustainable garden", then assessment criteria should be "A sustainable garden is designed"
           - Example: If learning activity is "Create a digital presentation", then assessment criteria should be "A digital presentation is created"
           - Example: If learning activity is "Conduct a scientific experiment", then assessment criteria should be "A scientific experiment is conducted"
           - All assessment criteria must be in passive voice, present tense
           - No qualifiers like 'correctly' or 'properly' should be used
           - Include ICT-related assessment criteria where applicable
           - MAINTAIN THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
           - Ensure project activities align with the grade level's core competencies
        6. Real-world applications and connections
        7. Collaboration and teamwork
        8. USE THE SAME LANGUAGE AS THE MAIN LEARNING ACTIVITY
        9. Design project activities that match the grade level's:
           - Cognitive development
           - Attention span
           - Motor skills
           - Language development
           - Social development
           - Core competencies
        ''' if lesson_type and lesson_type.lower() == 'project' else ''}

        The lesson plan should follow the IDDR model and 5E's approach:
        1. Introduction (Engage) - Variation Principle: CONTRAST
        2. Competence Development (Explore/Explain) - Variation Principle: SEPARATION
        3. Design (Elaborate) - Variation Principle: GENERALIZATION
        4. Realisation (Evaluate) - Variation Principle: FUSION

        SPECIFIC LEARNING ACTIVITIES AND FEATURES FORMAT:
        - \"Main Learning Activity\": Must show the user-provided main goal
        - \"Specific_Learning_Activities\": Break down the main activity into sub-activities with bullet Features
        Example:
        \"Specific_Learning_Activities\": {{
            \"1\": {{
                \"Activity\": \"Identify Number Positions\",
                \"Features\": [
                    \"Locate positions of digits\",
                    \"Name each place value\"
                ]
            }},
            \"2\": {{
                \"Activity\": \"Represent Values\",
                \"Features\": [
                    \"Use base-10 blocks\",
                    \"Convert representations\"
                ]
            }}
        }}

        \"Lesson_Plan\": [
            {{
                \"Stage\": \"Introduction\",
                \"Time (Minutes)\": \"{time_distribution['introduction']}\",
                \"Teaching Activities\": \"...\",
                \"Learning Activities\": \"...\",
                \"Assessment Criteria\": \"...\",
                \"Variation Principle\": \"CONTRAST\",
                \"5E Component\": \"Engage\"
            }},
            ...
        ],

        REMARKS FORMAT:
        - \"Students were able to [...]. However, some students failed [...]. Therefore, I will [...]\"

        Return the lesson plan in JSON:
        {{
            \"Main_Learning_Activity\": \"{main_learningactivity}\",
            \"Specific_Learning_Activities\": {{
                \"1\": {{
                    \"Activity\": \"Activity Title\",
                    \"Features\": [\"Feature 1\", \"Feature 2\"]
                }},
                \"2\": {{
                    \"Activity\": \"Another Activity Title\",
                    \"Features\": [\"Feature 1\", \"Feature 2\"]
                }}
            }},
            \"Lesson_Plan\": [...],
            \"Remarks\": [...]
        }}

        IMPORTANT: Return valid JSON only. Do not include any extra text.
        """

        # Call the OpenAI API
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a professional lesson planner. Your task is to create "
                        "detailed lesson plans following the IDDR model and 5E's approach. "
                        "Always return valid JSON."
                    )
                },
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=2000
        )

        response_text = response.choices[0].message.content.strip()
        
        # Clean up the response text
        response_text = response_text.replace("```json", "").replace("```", "").strip()
        
        try:
            lesson_plan = json.loads(response_text)
            
            # Validate keys
            required_keys = ["Main_Learning_Activity", "Specific_Learning_Activities", "Lesson_Plan", "Remarks"]
            for key in required_keys:
                if key not in lesson_plan:
                    raise ValueError(f"Missing required key in lesson plan: {key}")
            
            # Ensure key sections exist
            if "Specific_Learning_Activities" not in lesson_plan:
                lesson_plan["Specific_Learning_Activities"] = {}
            
            if "Lesson_Plan" not in lesson_plan:
                lesson_plan["Lesson_Plan"] = []
            
            if "Remarks" not in lesson_plan:
                lesson_plan["Remarks"] = []
            
            # Make sure Teaching Activities are teacher-focused (not starting with 'Students')
            for stage in lesson_plan.get("Lesson_Plan", []):
                if "Teaching Activities" in stage:
                    teaching_activities = stage["Teaching Activities"]
                    if teaching_activities.lower().startswith("students"):
                        teaching_activities = teaching_activities[8:].strip()
                        teaching_activities = teaching_activities[0].upper() + teaching_activities[1:]
                        stage["Teaching Activities"] = teaching_activities
            
            return lesson_plan

        except json.JSONDecodeError as e:
            print(f"Initial JSON parsing failed: {str(e)}")
            print(f"Raw response: {response_text}")
            
            # Try cleanup
            response_text = response_text.replace("'", '"')  
            response_text = re.sub(r'(\\w+):', r'\"\\1\":', response_text)
            response_text = re.sub(r',\\s*}', '}', response_text)
            response_text = re.sub(r',\\s*]', ']', response_text)
            
            try:
                lesson_plan = json.loads(response_text)
                # Validate again
                required_keys = ["Main_Learning_Activity", "Specific_Learning_Activities", "Lesson_Plan", "Remarks"]
                for key in required_keys:
                    if key not in lesson_plan:
                        raise Exception(f"Missing required key in lesson plan: {key}")
                return lesson_plan
            except json.JSONDecodeError as e:
                print(f"Second JSON parsing attempt failed: {str(e)}")
                print(f"Cleaned response: {response_text}")
                
                return {
                    "Main_Learning_Activity": main_learningactivity,
                    "Specific_Learning_Activities": {
                        "1": {
                            "Activity": "Activity related to " + main_learningactivity,
                            "Features": ["Feature 1", "Feature 2"]
                        }
                    },
                    "Lesson_Plan": [
                        {
                            "Stage": "Introduction",
                            "Time (Minutes)": time_distribution['introduction'],
                            "Teaching Activities": f"Show examples related to {main_learningactivity}",
                            "Learning Activities": "Activity 1",
                            "Assessment Criteria": "Criterion 1",
                            "Variation Principle": "CONTRAST",
                            "5E Component": "Engage"
                        }
                    ],
                    "Remarks": [
                        "Error occurred while generating the full lesson plan. Simplified version provided."
                    ]
                }
        
        except Exception as e:
            print(f"Error generating lesson plan: {str(e)}")
            return {
                "Main_Learning_Activity": main_learningactivity,
                "Specific_Learning_Activities": {
                    "1": {
                        "Activity": "Activity related to " + main_learningactivity,
                        "Features": ["Feature 1", "Feature 2"]
                    }
                },
                "Lesson_Plan": [
                    {
                        "Stage": "Introduction",
                        "Time (Minutes)": time_distribution['introduction'],
                        "Teaching Activities": f"Show examples related to {main_learningactivity}",
                        "Learning Activities": "Activity 1",
                        "Assessment Criteria": "Criterion 1",
                        "Variation Principle": "CONTRAST",
                        "5E Component": "Engage"
                    }
                ],
                "Remarks": [
                    "Error occurred while generating the full lesson plan. Simplified version provided."
                ]
            }

    except Exception as e:
        print(f"Error generating lesson plan: {str(e)}")
        return {
            "Main_Learning_Activity": main_learningactivity,
            "Specific_Learning_Activities": {
                "1": {
                    "Activity": "Activity related to " + main_learningactivity,
                    "Features": ["Feature 1", "Feature 2"]
                }
            },
            "Lesson_Plan": [
                {
                    "Stage": "Introduction",
                    "Time (Minutes)": time_distribution['introduction'],
                    "Teaching Activities": f"Show examples related to {main_learningactivity}",
                    "Learning Activities": "Activity 1",
                    "Assessment Criteria": "Criterion 1",
                    "Variation Principle": "CONTRAST",
                    "5E Component": "Engage"
                }
            ],
            "Remarks": [
                "Error occurred while generating the full lesson plan. Simplified version provided."
            ]
        }

def customize_lesson_plan(current_lesson_plan, customization, lesson_type=None):
    """
    Customize an existing lesson plan based on user requests.
    This function calls the OpenAI API to adjust the existing plan
    according to the user's customization request, then returns
    a new or updated JSON lesson plan.
    """
    print(f"Starting customization with request: {customization}")
    print(f"Lesson type: {lesson_type}")
    
    try:
        # Input validation
        if not isinstance(current_lesson_plan, dict):
            print("Error: Invalid lesson plan format - not a dictionary")
            return {"Error": "Invalid lesson plan format"}
        
        if not isinstance(customization, str) or not customization.strip():
            print("Error: Invalid customization request - empty or not a string")
            return {"Error": "Invalid customization request"}
        
        # Extract essential information
        original_main_activity = current_lesson_plan.get("Main_Learning_Activity", "")
        if not original_main_activity:
            print("Error: Missing Main_Learning_Activity in lesson plan")
            return {"Error": "Missing Main_Learning_Activity in lesson plan"}
        
        # Get grade level and time distribution
        grade_level = current_lesson_plan.get("Grade_Level", "")
        time_distribution = {}
        if "Lesson_Plan" in current_lesson_plan:
            for stage in current_lesson_plan["Lesson_Plan"]:
                if "Stage" in stage and "Time (Minutes)" in stage:
                    time_distribution[stage["Stage"]] = stage["Time (Minutes)"]
        
        # Get age-appropriate guidelines
        age_guidelines = get_age_appropriate_guidelines(grade_level) if grade_level else {}
        
        # Prepare the prompt
        prompt = f"""Modify the following lesson plan based on this request: "{customization}"

        Current Lesson Plan:
        {json.dumps(current_lesson_plan, indent=2)}
        
        Lesson Type: {lesson_type if lesson_type else "regular"}
        
        CRITICAL INSTRUCTIONS:
        1. Keep the Main_Learning_Activity exactly as it is: \"{original_main_activity}\"
        2. Do not remove keys: \"Main_Learning_Activity\", \"Specific_Learning_Activities\", \"Lesson_Plan\", \"Remarks\"
        3. Maintain IDDR + 5E structure
        4. Keep assessment criteria in passive voice, present tense
        5. Ensure all modifications align with the original learning objectives
        6. Maintain the same language as the Main Learning Activity
        7. Keep the same time distribution for each stage:
           {json.dumps(time_distribution, indent=2)}
        8. Ensure activities are age-appropriate and match the grade level's:
           - Cognitive development
           - Attention span
           - Activity complexity
           - Group work capabilities
           - Technology use
           - Assessment approach
           - Motor skills
           - Language development
           - Social development
        9. Return valid JSON only, with no extra text
        """

        print("Sending request to OpenAI API...")
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a professional lesson planner. Your task is to modify "
                        "existing lesson plans while maintaining their core structure and objectives. "
                        "Always return valid JSON and ensure all modifications align with the original "
                        "learning goals and age-appropriate guidelines. "
                        "IMPORTANT: Return ONLY the JSON object, no additional text or explanations."
                    )
                },
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=2000
        )

        response_text = response.choices[0].message.content.strip()
        print("Received response from OpenAI API")
        
        # Clean up the response
        response_text = response_text.replace("```json", "").replace("```", "").strip()
        
        try:
            print("Attempting to parse JSON response...")
            customized_plan = json.loads(response_text)
        except json.JSONDecodeError as e:
            print(f"Initial JSON parsing failed: {str(e)}")
            print("Attempting cleanup and re-parsing...")
            
            # More thorough cleanup
            cleaned_text = response_text.replace("'", '"')
            cleaned_text = re.sub(r'(\\w+):', r'\"\\1\":', cleaned_text)
            cleaned_text = re.sub(r',\\s*}', '}', cleaned_text)
            cleaned_text = re.sub(r',\\s*]', ']', cleaned_text)
            cleaned_text = re.sub(r'\\n', ' ', cleaned_text)
            cleaned_text = re.sub(r'\\s+', ' ', cleaned_text)
            
            try:
                customized_plan = json.loads(cleaned_text)
                print("Successfully parsed JSON after cleanup")
            except json.JSONDecodeError as e:
                print(f"Second JSON parsing attempt failed: {str(e)}")
                print("Returning original plan with error")
                return {
                    "Error": "Failed to parse customized lesson plan",
                    "Original_Plan": current_lesson_plan
                }
        
        # Validate required keys
        print("Validating required keys...")
        required_keys = ["Main_Learning_Activity", "Specific_Learning_Activities", "Lesson_Plan", "Remarks"]
        for key in required_keys:
            if key not in customized_plan:
                print(f"Error: Missing required key: {key}")
                raise Exception(f"Missing required key in lesson plan: {key}")
        
        # Ensure the Main_Learning_Activity remains unchanged
        customized_plan["Main_Learning_Activity"] = original_main_activity
        
        # Ensure minimal structure is present
        if "Specific_Learning_Activities" not in customized_plan:
            customized_plan["Specific_Learning_Activities"] = {}
        if "Lesson_Plan" not in customized_plan:
            customized_plan["Lesson_Plan"] = []
        if "Remarks" not in customized_plan:
            customized_plan["Remarks"] = []
        
        # Validate time distribution matches original
        print("Validating time distribution...")
        if "Lesson_Plan" in current_lesson_plan and "Lesson_Plan" in customized_plan:
            for original_stage, new_stage in zip(current_lesson_plan["Lesson_Plan"], customized_plan["Lesson_Plan"]):
                if "Time (Minutes)" in original_stage and "Time (Minutes)" in new_stage:
                    new_stage["Time (Minutes)"] = original_stage["Time (Minutes)"]
        
        # Ensure Teaching Activities are teacher-focused
        print("Validating teaching activities...")
        for stage in customized_plan.get("Lesson_Plan", []):
            if "Teaching Activities" in stage:
                teaching_activities = stage["Teaching Activities"]
                if teaching_activities.lower().startswith("students"):
                    teaching_activities = teaching_activities[8:].strip()
                    teaching_activities = teaching_activities[0].upper() + teaching_activities[1:]
                    stage["Teaching Activities"] = teaching_activities
        
        print("Customization completed successfully")
        return customized_plan

    except Exception as e:
        print(f"Error in customization process: {str(e)}")
        print(f"Error type: {type(e).__name__}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        return {
            "Error": f"Could not customize lesson plan: {str(e)}",
            "Original_Plan": current_lesson_plan
        }
