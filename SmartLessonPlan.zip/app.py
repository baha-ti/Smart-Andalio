# Save this as app.py

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import os
from dotenv import load_dotenv
import requests  # for catching network/connection errors if needed
from lesson_plan import generate_lesson_plan, customize_lesson_plan, calculate_time_distribution
from interdisciplinary_lesson_plan import generate_interdisciplinary_lesson_plan
from openai import OpenAI
import json

load_dotenv()  # Load environment variables

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# For session management, ensure you have a secure, persistent secret key in production
app.secret_key = os.urandom(24)

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

@app.route('/')
def index():
    # Render your index or UI page
    return render_template('index.html')

@app.route('/generate_lesson_plan', methods=['POST'])
def generate_lesson_plan_route():
    try:
        if not request.is_json:
            return jsonify({'error': 'Request must be JSON'}), 400

        data = request.get_json()
        print("Received data:", data)  # Debug log

        # Keep using specific_activity as the field name
        required_fields = ['specific_activity', 'grade_level', 'lesson_duration', 'lesson_type']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400

        # Calculate time distribution
        time_distribution = calculate_time_distribution(data['lesson_duration'], data['grade_level'])

        # Use specific_activity consistently
        if data['lesson_type'].lower() == 'interdisciplinary':
            lesson_plan = generate_interdisciplinary_lesson_plan(
                main_learningactivity=data['specific_activity'],
                grade_level=data['grade_level'],
                lesson_duration=data['lesson_duration'],
                time_distribution=time_distribution
            )
        else:
            lesson_plan = generate_lesson_plan(
                main_learningactivity=data['specific_activity'],
                grade_level=data['grade_level'],
                lesson_duration=data['lesson_duration'],
                time_distribution=time_distribution,
                lesson_type=data['lesson_type']
            )

        return jsonify(lesson_plan)

    except requests.exceptions.RequestException as net_err:
        # Add more detailed error logging
        print(f"[Network Error in generate_lesson_plan_route]: {str(net_err)}")
        return jsonify({
            'error': 'A network error occurred while generating the lesson plan. '
                     'Please check your internet connection or try again later.',
            'details': str(net_err)
        }), 503

    except ValueError as val_err:
        print(f"[ValueError in generate_lesson_plan_route]: {str(val_err)}")
        return jsonify({
            'error': str(val_err),
            'details': 'Invalid input provided'
        }), 400

    except Exception as e:
        print(f"Error in generate_lesson_plan_route: {str(e)}")  # Debug log
        return jsonify({'error': str(e)}), 500

@app.route('/customize_lesson_plan', methods=['POST'])
def customize_lesson_plan_route():
    try:
        # Ensure request is JSON
        if not request.is_json:
            return jsonify({'error': 'Request must be JSON'}), 400

        data = request.get_json()

        # Validate required fields
        required_fields = ['current_lesson_plan', 'customization']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400

        # Optional: get lesson_type if provided
        lesson_type = data.get('lesson_type', None)

        # Create a prompt for customization
        prompt = f"""
        Current lesson plan: {data['current_lesson_plan']}
        Customization request: {data['customization']}
        
        Please modify the lesson plan according to the customization request while maintaining the same structure and format.
        """
        
        # Call OpenAI API for customization
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a helpful teaching assistant that customizes lesson plans."},
                {"role": "user", "content": prompt}
            ]
        )
        
        # Parse the response and return the customized lesson plan
        customized_plan = response.choices[0].message.content
        return jsonify(customized_plan)

    except requests.exceptions.RequestException as net_err:
        # Catch network/connection-related errors
        print(f"[Network Error in customize_lesson_plan_route]: {str(net_err)}")
        return jsonify({
            'error': 'A network error occurred while customizing the lesson plan. '
                     'Please check your internet connection or try again later.'
        }), 503

    except ValueError as val_err:
        print(f"[ValueError in customize_lesson_plan_route]: {str(val_err)}")
        return jsonify({'error': str(val_err)}), 400

    except Exception as e:
        print(f"[Error in customize_lesson_plan_route]: {str(e)}")
        return jsonify({'error': 'An unexpected error occurred while customizing the lesson plan. Please try again.'}), 500

@app.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400

        message = data.get('message')
        context = data.get('context', {})
        
        # Create a system message that sets the context
        system_message = """You are a helpful teaching assistant that provides guidance on lesson planning and teaching strategies. 
        You can help with:
        - Explaining teaching concepts
        - Suggesting activities and resources
        - Providing assessment strategies
        - Offering classroom management tips
        - Answering questions about pedagogy
        """
        
        # Add context about the current lesson plan if available
        if context.get('current_lesson_plan'):
            system_message += f"\nCurrent lesson plan context: {context['current_lesson_plan']}"
        
        try:
            # Call OpenAI API using the new client
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_message},
                    {"role": "user", "content": message}
                ],
                temperature=0.7,
                max_tokens=1000
            )
            
            return jsonify({'response': response.choices[0].message.content})
            
        except Exception as api_error:
            print(f"OpenAI API Error: {str(api_error)}")
            return jsonify({
                'error': 'Failed to get response from the AI assistant. Please try again later.',
                'details': str(api_error)
            }), 500
            
    except Exception as e:
        print(f"Chat endpoint error: {str(e)}")
        return jsonify({
            'error': 'An unexpected error occurred. Please try again later.',
            'details': str(e)
        }), 500

@app.route('/translate_lesson_plan', methods=['POST'])
def translate_lesson_plan():
    try:
        print("Received translation request")
        if not request.is_json:
            print("Request is not JSON")
            return jsonify({'error': 'Request must be JSON'}), 400

        data = request.get_json()
        print(f"Received data: {data}")
        
        required_fields = ['lesson_plan', 'target_language', 'lesson_type']
        for field in required_fields:
            if field not in data:
                print(f"Missing required field: {field}")
                return jsonify({'error': f'Missing required field: {field}'}), 400

        lesson_plan = data['lesson_plan']
        target_language = data['target_language'].strip()
        lesson_type = data['lesson_type']

        # Enforce English-to-Swahili-to-English translation only
        if target_language.lower() != "swahili":
            print("Warning: Only English-to-Swahili translation is supported. Overriding target language to 'Swahili'.")
            target_language = "Swahili"
        
        print(f"Translating to: {target_language}")
        
        # Create a prompt for translation
        prompt = f"""
        You are a professional translator. Your task is to translate the following lesson plan from English to {target_language}.
        
        IMPORTANT INSTRUCTIONS:
        1. You MUST translate the content to {target_language} even if parts of the lesson plan are already in English.
        2. Maintain the exact same HTML structure and formatting.
        3. Keep all HTML tags and classes intact.
        4. Translate all visible text content while preserving:
           - Educational terminology
           - Assessment criteria
           - Technical terms
           - Level of formality
           - All formatting and structure.
        
        DO NOT provide any explanation or additional comments. ONLY provide the translated content.
        
        Lesson Plan to translate:
        {lesson_plan}
        """
        
        print("Sending request to OpenAI for translation")
        # Call OpenAI API for translation
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system", 
                    "content": f"You are a professional translator specializing in educational content. You MUST translate all content to {target_language}, maintaining the exact same structure and formatting."
                },
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,  # Lower temperature for more deterministic translation
            max_tokens=1500   # Increase max tokens if lesson plan content is long
        )
        
        print("Received response from OpenAI for translation")
        translated_plan = response.choices[0].message.content
        print(f"Translated content (first 100 characters): {translated_plan[:100]}...")
        
        # Return the translated content
        return jsonify({'translated_content': translated_plan})

    except Exception as e:
        print(f"[Error in translate_lesson_plan]: {str(e)}")
        return jsonify({'error': 'An error occurred while translating the lesson plan. Please try again.'}), 500

if __name__ == '__main__':
    # Adjust host/port if needed. 0.0.0.0 is typical for container deployments.
    # In production, disable debug mode and set a stable secret key.
    app.run(debug=True, host='0.0.0.0', port=5000)
